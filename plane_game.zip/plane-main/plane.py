import pygame
import random
import sys

pygame.init()

WIDTH = HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Plane war")

MAX_BULLETS = 30

background = pygame.image.load("IMG/Image/background.png")
new_background = pygame.transform.scale(background, (WIDTH, HEIGHT))

grass = pygame.image.load("IMG/Image/grass.png")
new_grass = pygame.transform.scale(grass, (600, 150))

class Player:
    def __init__(self, x, y, w, h, speed, direction, max_fuel):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.speed = speed
        self.direction = direction
        self.fuel_count = max_fuel
        self.max_fuel = max_fuel
        self.plane_image = pygame.image.load("IMG/Image/plane.png")
        self.plane_left_img = pygame.image.load("IMG/Image/plane_left.png")
        self.plane_right_img = pygame.image.load("IMG/Image/plane_right.png")
        self.turret_image = pygame.image.load("IMG/Image/turret.png")
        self.turret_scale_image = pygame.transform.scale(self.turret_image, (20, 45))
        self.image = pygame.transform.scale(self.plane_image, (60, 75))
        self.rect = self.image.get_rect()
        self.damage = 1
        self.cool_down_counter = 0
        self.bullets = []
        self.score_count = 0

    def score(self, value):
        self.score_count += value


    def shoot(self):
        if self.cool_down_counter == 0:
            bullet = Bullet(self.rect.x + 15, self.rect.y + 95, 10,15, 8, "down")
            self.bullets.append(bullet)
            self.cool_down_counter = 1

    def cool_down(self):
        if self.cool_down_counter >= MAX_BULLETS:
            self.cool_down_counter = 0
        elif self.cool_down_counter > 0:
            self.cool_down_counter += 1

    def draw(self, window):
        window.blit(self.turret_scale_image, (self.rect.x + 20, self.rect.y + 50))
        if self.direction == "left" and self.rect.x > 0:
            window.blit(self.plane_left_img, (self.rect.x, self.rect.y))

        elif self.direction == "right" and self.rect.x < WIDTH - self.w:
            window.blit(self.plane_right_img, (self.rect.x, self.rect.y))

        else:
            window.blit(self.image, (self.rect.x, self.rect.y))


    def move(self):
        self.cool_down()
        if self.direction == "left" and self.rect.x > 0:
            self.rect.x -= self.speed
        elif self.direction == "right" and self.rect.x < WIDTH - self.w:
            self.rect.x += self.speed
        elif self.direction == "up" and self.rect.y > 0:
            self.rect.y -= self.speed
        elif self.direction == "down" and self.rect.y < HEIGHT - self.h - 150 + 5:
            self.rect.y += self.speed

    def fuel(self, target):
        self.fuel_count -= 0.1 * self.damage
        if self.fuel_count <= 0:
            self.fuel_count = 0
        if self.rect.colliderect(target.rect):
            self.fuel_count += 1
        if self.fuel_count >= 100:
            self.fuel_count = 100

    def draw_fuel_bar(self, window):
        ratio = self.fuel_count / self.max_fuel
        pygame.draw.rect(window, "white", (98, 28, 404, 24))
        pygame.draw.rect(window, "red", (100, 30, 400, 20))
        pygame.draw.rect(window, "green", (100, 30, 400 * ratio, 20))

class Enemy(Player):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.image_1 = pygame.image.load("IMG/Image/enemy.png")
        self.image_2 = pygame.image.load("IMG/Image/enemy_turret.png")
        self.image_2_scale = pygame.transform.scale(self.image_2, (40, 100))
        self.image = pygame.transform.scale(self.image_1, (80, 60))
        self.rect = self.image.get_rect()
        self.x_speed = 3
        self.bullets = []
        self.cool_down_counter = 0

    def reset_position(self, target):
        self.rect.x = random.randint(0, WIDTH - self.width - target.w)
        self.rect.y = 800

    def shoot(self):
        if self.cool_down_counter == 0:
            bullet = Bullet(self.rect.x + 50, self.rect.y - 35, 10,15, 6, "up")
            self.bullets.append(bullet)
            self.cool_down_counter = 1

    def cool_down(self):
        if self.cool_down_counter >= MAX_BULLETS:
            self.cool_down_counter = 0
        elif self.cool_down_counter > 0:
            self.cool_down_counter += 1

    def move(self):
        self.cool_down()
        self.rect.x += self.x_speed
        if self.rect.right > WIDTH or self.rect.left < 0:
            self.x_speed = -self.x_speed

        self.rect.y -= 5
        if self.rect.y <= 500:
            self.rect.y = 500

    def draw(self, window):
        window.blit(self.image_2_scale, (self.rect.x + 20, self.rect.y - 65))
        window.blit(self.image, (self.rect.x, self.rect.y))
        
class FuelBarrel:
    def __init__(self,x, y, width, height):
        self.width = width
        self.height = height
        self.image = pygame.image.load("IMG/Image/fuel_barrel.png")
        self.rect = self.image.get_rect()

    def reset_position(self):
        self.rect.x = random.randint(0, 600 - self.width)
        self.rect.y = -100

    def move(self):
        self.rect.y += 2
        if self.rect.y >= 600:
            self.rect.x = random.randint(0, 600)
            self.rect.y = -100

    def draw(self, window):
        screen.blit(self.image, (self.rect.x, self.rect.y))

class Bullet:
    def __init__(self, x, y, width, height, speed, direction):
        self.width = width
        self.height = height
        self.speed = speed
        self.direction = direction
        self.rect = pygame.Rect(x, y, self.width, self.height)

    def move(self):
        if self.direction == "up":
            self.rect.y -= self.speed
        elif self.direction == "down":
            self.rect.y += self.speed

    def draw(self, window):
        pygame.draw.rect(window, "white", (self.rect.x, self.rect.y, self.width, self.height))


player = Player(100, 100, 40, 50, 5, "left", 100)
enemy = Enemy(300, 500, 60, 40)
fuel_barrel = FuelBarrel(random.randint(0, 600), -100, 20, 30)

print(
    "If you pressed: \n"
    "keys arrows: move \n"
    "key space: shoot \n"
    "If you collide with fuel barrels(yellow rect): \n"
    "fuel increases by 25 \n"
    "good luck"
)

def write(text, x, y, color, size):
    font = pygame.font.Font("IMG/Font/Pixellari.ttf", size)
    rend = font.render(text, 1, color)
    screen.blit(rend, (x, y))

clock = pygame.time.Clock()
while True:

    player.cool_down()
    enemy.cool_down()

    player.fuel(fuel_barrel)


    screen.blit(new_background, (0, 0))
    screen.blit(new_grass, (0, 450))
    pygame.draw.circle(screen, "dark gray", (450, 100), 80)

    player.draw(screen)
    enemy.draw(screen)
    player.draw_fuel_bar(screen)
    fuel_barrel.draw(screen)

    write("Fuel", 5, 20, "white", 45)
    write(f"Score: {player.score_count}", 5, 60, "white", 45)

    enemy.move()
    fuel_barrel.move()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.shoot()

    keyboard = pygame.key.get_pressed()
    if keyboard[pygame.K_LEFT]:
        player.move()
        player.direction = "left"
    if keyboard[pygame.K_RIGHT]:
        player.move()
        player.direction = "right"
    if keyboard[pygame.K_UP]:
        player.move()
        player.direction = "up"
    if keyboard[pygame.K_DOWN]:
        player.move()
        player.direction = "down"
    if keyboard[pygame.K_ESCAPE] or keyboard[pygame.K_q]:
        pygame.quit()
        sys.exit()

    for bullet in enemy.bullets:
        bullet.move()
        bullet.draw(screen)

        if player.rect.colliderect(bullet.rect):
            player.damage += 1
            enemy.bullets.remove(bullet)

    if random.randrange(0, 2 * 50) == 1:
        enemy.shoot()

    for bullet in player.bullets:
        bullet.move()
        bullet.draw(screen)

    for bullet in player.bullets:
        if (
            enemy.rect.x < bullet.rect.x < enemy.rect.x + enemy.width
            and enemy.rect.y < bullet.rect.y < enemy.rect.y + enemy.height
        ):
            player.bullets.remove(bullet.rect)

        if bullet.rect.colliderect(fuel_barrel.rect):
            fuel_barrel.reset_position()
            player.score(5)
            player.bullets.remove(bullet.rect)

        if bullet.rect.colliderect(enemy.rect):
            enemy.reset_position(player)
            player.score(30)

    if player.fuel_count <= 0:
        write("You've run out of fuel", 200, 300, "dark red", 40)
        pygame.display.flip()
        pygame.time.delay(2000)
        pygame.quit()
        sys.exit()

    if player.rect.y >= HEIGHT - player.h - 150 + 5:
        write("You crashed on the ground", 100, 300, "dark red", 40)
        pygame.display.flip()
        pygame.time.delay(2000)
        pygame.quit()
        sys.exit()



    pygame.display.update()
    clock.tick(60)